﻿Write-Host 'updating custom SSRS reports for SSMS from Network folder'
$custom_reports = @("TableSummary.rdl", "ColumnHistogram.rdl")
$src_folder = "\\vchdfsp04\Departments\QUIST\Production\GrahamCrowell\SSRS_TableSummary"
$dest_folder = $env:HOMEDRIVE+"\SQL Server Management Studio\Custom Reports"

if(Test-Path $dest_folder) 
{
    Write-Host ('destination: {0}' -f $dest_folder)
}
else
{
    Write-Host ('ERROR: destination folder doesnt exist: {0}' -f $dest_folder)
    New-Item $dest_folder -type directory
    # Exit-PSSession
}
if(Test-Path $src_folder)
{
    Write-Host ('source: {0}' -f $src_folder)
}
else
{
    Write-Host ('ERROR: source folder doesnt exist: {0}' -f $dest_folder)
    # Exit-PSSession
}

$WScriptShell = New-Object -ComObject WScript.Shell
$custom_reports | ForEach-Object {
    Write-Host ("`tupdating: {0}" -f $_)
    $target_path = Join-Path -Path $src_folder -ChildPath $_
    if(Test-Path $target_path) 
    {
        Write-Host ('deleting old version: {0}' -f $target_path)
        Remove-Item $target_path
    }
    
    $shortcut_file = Join-Path -Path $src_folder -ChildPath $_+".lnk"
    $Shortcut = $WScriptShell.CreateShortcut($shortcut_file)
    $Shortcut.TargetPath = $target_path
    $Shortcut.Save()
    # Copy-Item -Path (Join-Path -Path $src_folder -ChildPath $_) -Destination $dest_folder

}

Write-Host "update complete"
Read-Host -Prompt 'Press ENTER to Exit'